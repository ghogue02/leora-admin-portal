# Wellcrafted Supabase MCP Server Setup

This directory contains the MCP server that connects Claude to your Wellcrafted Supabase database.

## Installation

1. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

2. **Configure Environment Variables**
   
   The MCP server requires two environment variables:
   - `SUPABASE_URL`: Your Supabase project URL
   - `SUPABASE_SERVICE_ROLE_KEY`: Your Supabase service role key (for full access)
   - OR `SUPABASE_ANON_KEY`: Your Supabase anon key (for read-only access)

## Claude Desktop Configuration

Add this to your Claude Desktop config file:

**macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
**Windows**: `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "wellcrafted": {
      "command": "python",
      "args": ["/absolute/path/to/supabase_mcp.py"],
      "env": {
        "SUPABASE_URL": "https://zqezunzlyjkseugujkrl.supabase.co",
        "SUPABASE_SERVICE_ROLE_KEY": "your_service_role_key_here"
      }
    }
  }
}
```

**Important**: Replace `/absolute/path/to/supabase_mcp.py` with the actual path where you extracted this skill.

## Testing the Server

To test that the server works correctly:

```bash
# Set environment variables
export SUPABASE_URL="https://zqezunzlyjkseugujkrl.supabase.co"
export SUPABASE_SERVICE_ROLE_KEY="your_service_role_key"

# Test the server (will hang waiting for stdin - this is normal)
python supabase_mcp.py
```

If no errors appear, the server is configured correctly. Press Ctrl+C to exit.

## Credentials

Your Wellcrafted Supabase credentials:
- **URL**: https://zqezunzlyjkseugujkrl.supabase.co
- **Anon Key**: (provided separately - for read-only operations)
- **Service Role Key**: (provided separately - for full access including writes)

## Security Notes

- **Service Role Key**: Has full database access. Keep it secure and never commit to version control.
- **Anon Key**: Respects Row Level Security (RLS) policies. Use for read-only operations if concerned about security.
- Store keys in environment variables or secure configuration, never in code.

## Troubleshooting

**"Module not found" errors:**
- Ensure all requirements are installed: `pip install -r requirements.txt`
- Check Python version is 3.8 or higher: `python --version`

**"Missing Supabase credentials" errors:**
- Verify environment variables are set correctly
- Check that keys don't have extra spaces or quotes
- Confirm SUPABASE_URL includes the full URL with https://

**"Permission denied" errors:**
- Check if Row Level Security (RLS) is enabled on tables
- Use SERVICE_ROLE_KEY instead of ANON_KEY for write operations
- Verify credentials are correct in Supabase dashboard

**Connection errors:**
- Verify your Supabase URL is correct
- Check internet connection
- Confirm Supabase project is not paused (free tier auto-pauses after inactivity)

## Available Tools

The MCP server provides these tools for Claude:

1. **supabase_list_tables** - Discover available tables
2. **supabase_describe_table** - View table schema and sample data
3. **supabase_query_table** - Query records with filtering and sorting
4. **supabase_insert_record** - Create new records
5. **supabase_update_records** - Update existing records
6. **supabase_delete_records** - Delete records (use with caution)
7. **supabase_count_records** - Count records in a table
8. **supabase_search_records** - Full-text search across columns

## Support

For issues or questions:
1. Check the main SKILL.md documentation
2. Review Supabase documentation: https://supabase.com/docs
3. Check MCP documentation: https://modelcontextprotocol.io
