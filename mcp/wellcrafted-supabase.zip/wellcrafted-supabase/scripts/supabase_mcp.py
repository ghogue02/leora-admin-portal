#!/usr/bin/env python3
"""
Supabase MCP Server
A comprehensive Model Context Protocol server for interacting with Supabase databases.
Provides tools for querying, inserting, updating, deleting records, and exploring database schema.
"""

import os
import json
from typing import Optional, List, Dict, Any, Union
from enum import Enum

from mcp.server.fastmcp import FastMCP
from pydantic import BaseModel, Field, field_validator, ConfigDict
from supabase import create_client, Client
import httpx

# Constants
CHARACTER_LIMIT = 25000  # Maximum response size in characters

# Initialize MCP server
mcp = FastMCP("supabase_mcp")

# Supabase client (will be initialized with credentials)
_supabase_client: Optional[Client] = None


def get_supabase_client() -> Client:
    """Get or create Supabase client instance."""
    global _supabase_client
    if _supabase_client is None:
        url = os.getenv("SUPABASE_URL")
        key = os.getenv("SUPABASE_SERVICE_ROLE_KEY") or os.getenv("SUPABASE_ANON_KEY")
        
        if not url or not key:
            raise ValueError(
                "Missing Supabase credentials. Set SUPABASE_URL and "
                "(SUPABASE_SERVICE_ROLE_KEY or SUPABASE_ANON_KEY) environment variables."
            )
        
        _supabase_client = create_client(url, key)
    
    return _supabase_client


# ============================================================================
# Enums and Models
# ============================================================================

class ResponseFormat(str, Enum):
    """Output format for tool responses."""
    MARKDOWN = "markdown"
    JSON = "json"


class FilterOperator(str, Enum):
    """Supported filter operators for queries."""
    EQ = "eq"           # Equal to
    NEQ = "neq"         # Not equal to
    GT = "gt"           # Greater than
    GTE = "gte"         # Greater than or equal to
    LT = "lt"           # Less than
    LTE = "lte"         # Less than or equal to
    LIKE = "like"       # Pattern matching
    ILIKE = "ilike"     # Case-insensitive pattern matching
    IN = "in"           # In list
    IS = "is"           # Is null/not null
    CONTAINS = "cs"     # Contains (for arrays/JSONB)
    OVERLAPS = "ov"     # Overlaps (for arrays)


# ============================================================================
# Tool Input Models
# ============================================================================

class ListTablesInput(BaseModel):
    """Input model for listing available tables."""
    model_config = ConfigDict(str_strip_whitespace=True, extra='forbid')
    
    response_format: ResponseFormat = Field(
        default=ResponseFormat.MARKDOWN,
        description="Output format: 'markdown' for human-readable or 'json' for structured data"
    )


class DescribeTableInput(BaseModel):
    """Input model for describing a table's schema."""
    model_config = ConfigDict(str_strip_whitespace=True, extra='forbid')
    
    table_name: str = Field(
        ...,
        description="Name of the table to describe (e.g., 'customers', 'orders', 'products')",
        min_length=1,
        max_length=100
    )
    response_format: ResponseFormat = Field(
        default=ResponseFormat.MARKDOWN,
        description="Output format: 'markdown' for human-readable or 'json' for structured data"
    )


class QueryTableInput(BaseModel):
    """Input model for querying a table with filters."""
    model_config = ConfigDict(str_strip_whitespace=True, extra='forbid')
    
    table_name: str = Field(
        ...,
        description="Name of the table to query (e.g., 'customers', 'orders', 'products')",
        min_length=1,
        max_length=100
    )
    columns: Optional[List[str]] = Field(
        default=None,
        description="Specific columns to retrieve (e.g., ['name', 'email', 'created_at']). If None, retrieves all columns (*)",
        max_length=50
    )
    filters: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Filter conditions as key-value pairs (e.g., {'status': 'active', 'region': 'west'})"
    )
    order_by: Optional[str] = Field(
        default=None,
        description="Column to sort by (e.g., 'created_at', 'name'). Prefix with '-' for descending (e.g., '-created_at')",
        max_length=100
    )
    limit: Optional[int] = Field(
        default=100,
        description="Maximum number of records to return",
        ge=1,
        le=1000
    )
    offset: Optional[int] = Field(
        default=0,
        description="Number of records to skip for pagination",
        ge=0
    )
    response_format: ResponseFormat = Field(
        default=ResponseFormat.MARKDOWN,
        description="Output format: 'markdown' for human-readable or 'json' for structured data"
    )


class InsertRecordInput(BaseModel):
    """Input model for inserting a new record."""
    model_config = ConfigDict(str_strip_whitespace=True, extra='forbid')
    
    table_name: str = Field(
        ...,
        description="Name of the table to insert into (e.g., 'customers', 'orders')",
        min_length=1,
        max_length=100
    )
    data: Dict[str, Any] = Field(
        ...,
        description="Record data as key-value pairs (e.g., {'name': 'John Doe', 'email': 'john@example.com'})"
    )
    response_format: ResponseFormat = Field(
        default=ResponseFormat.MARKDOWN,
        description="Output format: 'markdown' for human-readable or 'json' for structured data"
    )


class UpdateRecordInput(BaseModel):
    """Input model for updating existing records."""
    model_config = ConfigDict(str_strip_whitespace=True, extra='forbid')
    
    table_name: str = Field(
        ...,
        description="Name of the table to update (e.g., 'customers', 'orders')",
        min_length=1,
        max_length=100
    )
    filters: Dict[str, Any] = Field(
        ...,
        description="Filter conditions to match records to update (e.g., {'id': 123} or {'email': 'user@example.com'})"
    )
    data: Dict[str, Any] = Field(
        ...,
        description="New values as key-value pairs (e.g., {'status': 'completed', 'updated_at': 'now()'})"
    )
    response_format: ResponseFormat = Field(
        default=ResponseFormat.MARKDOWN,
        description="Output format: 'markdown' for human-readable or 'json' for structured data"
    )


class DeleteRecordInput(BaseModel):
    """Input model for deleting records."""
    model_config = ConfigDict(str_strip_whitespace=True, extra='forbid')
    
    table_name: str = Field(
        ...,
        description="Name of the table to delete from (e.g., 'customers', 'orders')",
        min_length=1,
        max_length=100
    )
    filters: Dict[str, Any] = Field(
        ...,
        description="Filter conditions to match records to delete (e.g., {'id': 123}). REQUIRED to prevent accidental deletion of all records"
    )
    response_format: ResponseFormat = Field(
        default=ResponseFormat.MARKDOWN,
        description="Output format: 'markdown' for human-readable or 'json' for structured data"
    )


class CountRecordsInput(BaseModel):
    """Input model for counting records in a table."""
    model_config = ConfigDict(str_strip_whitespace=True, extra='forbid')
    
    table_name: str = Field(
        ...,
        description="Name of the table to count records in (e.g., 'customers', 'orders')",
        min_length=1,
        max_length=100
    )
    filters: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Optional filter conditions (e.g., {'status': 'active'})"
    )
    response_format: ResponseFormat = Field(
        default=ResponseFormat.MARKDOWN,
        description="Output format: 'markdown' for human-readable or 'json' for structured data"
    )


class SearchRecordsInput(BaseModel):
    """Input model for full-text search across table columns."""
    model_config = ConfigDict(str_strip_whitespace=True, extra='forbid')
    
    table_name: str = Field(
        ...,
        description="Name of the table to search (e.g., 'customers', 'products')",
        min_length=1,
        max_length=100
    )
    search_term: str = Field(
        ...,
        description="Search term to look for (e.g., 'Chardonnay', 'john@example.com')",
        min_length=1,
        max_length=500
    )
    search_columns: Optional[List[str]] = Field(
        default=None,
        description="Columns to search in (e.g., ['name', 'description', 'email']). If None, searches all text columns",
        max_length=20
    )
    limit: Optional[int] = Field(
        default=50,
        description="Maximum number of results to return",
        ge=1,
        le=1000
    )
    response_format: ResponseFormat = Field(
        default=ResponseFormat.MARKDOWN,
        description="Output format: 'markdown' for human-readable or 'json' for structured data"
    )


class ExecuteSQLInput(BaseModel):
    """Input model for executing custom SQL queries."""
    model_config = ConfigDict(str_strip_whitespace=True, extra='forbid')
    
    sql_query: str = Field(
        ...,
        description="SQL query to execute (e.g., 'SELECT name, count(*) FROM orders GROUP BY name')",
        min_length=1,
        max_length=5000
    )
    response_format: ResponseFormat = Field(
        default=ResponseFormat.MARKDOWN,
        description="Output format: 'markdown' for human-readable or 'json' for structured data"
    )


# ============================================================================
# Helper Functions
# ============================================================================

def _handle_error(e: Exception) -> str:
    """Format errors in a user-friendly way."""
    error_msg = str(e)
    
    if "404" in error_msg or "not found" in error_msg.lower():
        return f"Error: Resource not found. Please check the table name or record ID is correct. Details: {error_msg}"
    elif "403" in error_msg or "permission" in error_msg.lower():
        return f"Error: Permission denied. You may need different credentials or Row Level Security (RLS) policies may be blocking access. Details: {error_msg}"
    elif "401" in error_msg or "unauthorized" in error_msg.lower():
        return f"Error: Authentication failed. Please check your Supabase credentials. Details: {error_msg}"
    elif "400" in error_msg or "bad request" in error_msg.lower():
        return f"Error: Invalid request. Please check your input parameters. Details: {error_msg}"
    
    return f"Error: An unexpected error occurred: {type(e).__name__}: {error_msg}"


def _format_response(data: Any, format_type: ResponseFormat, title: str = "") -> str:
    """Format response data as JSON or Markdown."""
    if format_type == ResponseFormat.JSON:
        return json.dumps(data, indent=2, default=str)
    
    # Markdown formatting
    output = []
    
    if title:
        output.append(f"# {title}\n")
    
    if isinstance(data, dict):
        for key, value in data.items():
            if isinstance(value, (list, dict)):
                output.append(f"**{key}:**\n```json\n{json.dumps(value, indent=2, default=str)}\n```\n")
            else:
                output.append(f"**{key}:** {value}")
    elif isinstance(data, list):
        if len(data) == 0:
            output.append("No records found.")
        else:
            output.append(f"Found {len(data)} record(s):\n")
            for i, item in enumerate(data, 1):
                output.append(f"## Record {i}\n")
                if isinstance(item, dict):
                    for key, value in item.items():
                        output.append(f"- **{key}:** {value}")
                else:
                    output.append(f"- {item}")
                output.append("")
    else:
        output.append(str(data))
    
    result = "\n".join(output)
    
    # Check character limit
    if len(result) > CHARACTER_LIMIT:
        result = result[:CHARACTER_LIMIT] + f"\n\n... (truncated at {CHARACTER_LIMIT} characters)"
    
    return result


def _apply_filters(query, filters: Optional[Dict[str, Any]]):
    """Apply filter conditions to a Supabase query."""
    if not filters:
        return query
    
    for column, value in filters.items():
        if value is None:
            query = query.is_(column, "null")
        elif isinstance(value, bool):
            query = query.eq(column, value)
        elif isinstance(value, (int, float, str)):
            query = query.eq(column, value)
        elif isinstance(value, list):
            query = query.in_(column, value)
        elif isinstance(value, dict) and "operator" in value:
            # Advanced filtering with operator
            op = value["operator"]
            val = value["value"]
            
            if op == "eq":
                query = query.eq(column, val)
            elif op == "neq":
                query = query.neq(column, val)
            elif op == "gt":
                query = query.gt(column, val)
            elif op == "gte":
                query = query.gte(column, val)
            elif op == "lt":
                query = query.lt(column, val)
            elif op == "lte":
                query = query.lte(column, val)
            elif op == "like":
                query = query.like(column, val)
            elif op == "ilike":
                query = query.ilike(column, val)
        else:
            # Default to equality
            query = query.eq(column, value)
    
    return query


# ============================================================================
# MCP Tools
# ============================================================================

@mcp.tool(
    name="supabase_list_tables",
    annotations={
        "title": "List Available Tables",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False
    }
)
async def list_tables(params: ListTablesInput) -> str:
    """List all available tables in the Supabase database.
    
    This tool discovers what tables exist in the database by attempting to query
    common table names. Useful for exploring the database schema.
    
    Args:
        params (ListTablesInput): Contains response_format
    
    Returns:
        str: List of available tables with row counts
    """
    try:
        supabase = get_supabase_client()
        
        # Common table names to check
        potential_tables = [
            'customers', 'clients', 'accounts', 'contacts',
            'products', 'wines', 'inventory', 'catalog', 'items',
            'orders', 'sales', 'invoices', 'quotes', 'transactions',
            'producers', 'suppliers', 'vendors', 'wineries', 'brands',
            'distributors', 'territories', 'regions', 'locations',
            'users', 'staff', 'employees', 'team',
            'notes', 'activities', 'tasks', 'events', 'interactions',
            'prices', 'pricing', 'discounts', 'promotions',
            'shipments', 'deliveries', 'fulfillments',
            'categories', 'types', 'classifications'
        ]
        
        tables_info = []
        
        for table in potential_tables:
            try:
                # Try to count records in the table
                result = supabase.table(table).select("*", count="exact").limit(0).execute()
                count = result.count if hasattr(result, 'count') else 0
                tables_info.append({
                    "table_name": table,
                    "row_count": count
                })
            except:
                # Table doesn't exist or we don't have access
                pass
        
        if not tables_info:
            return _format_response(
                {"message": "No tables found. The database may be empty or use different table names."},
                params.response_format,
                "Database Tables"
            )
        
        return _format_response(
            {
                "total_tables": len(tables_info),
                "tables": tables_info
            },
            params.response_format,
            "Database Tables"
        )
    
    except Exception as e:
        return _handle_error(e)


@mcp.tool(
    name="supabase_describe_table",
    annotations={
        "title": "Describe Table Schema",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False
    }
)
async def describe_table(params: DescribeTableInput) -> str:
    """Describe the schema of a specific table, showing columns and sample data.
    
    This tool retrieves a sample record from the table to infer the column structure.
    Useful for understanding what data is available in a table.
    
    Args:
        params (DescribeTableInput): Contains table_name and response_format
    
    Returns:
        str: Table schema with column names, types, and sample values
    """
    try:
        supabase = get_supabase_client()
        
        # Get a sample record to infer schema
        result = supabase.table(params.table_name).select("*").limit(1).execute()
        
        if not result.data or len(result.data) == 0:
            return _format_response(
                {
                    "table_name": params.table_name,
                    "message": "Table exists but is empty. No schema information available."
                },
                params.response_format,
                f"Table: {params.table_name}"
            )
        
        sample_record = result.data[0]
        columns_info = []
        
        for col_name, value in sample_record.items():
            columns_info.append({
                "column_name": col_name,
                "inferred_type": type(value).__name__,
                "sample_value": value
            })
        
        # Get total row count
        count_result = supabase.table(params.table_name).select("*", count="exact").limit(0).execute()
        row_count = count_result.count if hasattr(count_result, 'count') else "unknown"
        
        return _format_response(
            {
                "table_name": params.table_name,
                "row_count": row_count,
                "columns": columns_info
            },
            params.response_format,
            f"Table Schema: {params.table_name}"
        )
    
    except Exception as e:
        return _handle_error(e)


@mcp.tool(
    name="supabase_query_table",
    annotations={
        "title": "Query Table Records",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False
    }
)
async def query_table(params: QueryTableInput) -> str:
    """Query records from a table with optional filtering, sorting, and pagination.
    
    This is the primary tool for retrieving data from the database. Supports:
    - Column selection
    - Filtering by multiple conditions
    - Sorting (ascending or descending)
    - Pagination with limit and offset
    
    Args:
        params (QueryTableInput): Query parameters
    
    Returns:
        str: Query results with matching records
    """
    try:
        supabase = get_supabase_client()
        
        # Start building query
        columns = ",".join(params.columns) if params.columns else "*"
        query = supabase.table(params.table_name).select(columns, count="exact")
        
        # Apply filters
        query = _apply_filters(query, params.filters)
        
        # Apply ordering
        if params.order_by:
            if params.order_by.startswith("-"):
                # Descending order
                column = params.order_by[1:]
                query = query.order(column, desc=True)
            else:
                # Ascending order
                query = query.order(params.order_by)
        
        # Apply pagination
        if params.limit:
            query = query.limit(params.limit)
        if params.offset:
            query = query.offset(params.offset)
        
        # Execute query
        result = query.execute()
        
        total_count = result.count if hasattr(result, 'count') else len(result.data)
        
        response = {
            "total_count": total_count,
            "returned_count": len(result.data),
            "offset": params.offset,
            "limit": params.limit,
            "has_more": total_count > (params.offset + len(result.data)),
            "records": result.data
        }
        
        return _format_response(response, params.response_format, f"Query Results: {params.table_name}")
    
    except Exception as e:
        return _handle_error(e)


@mcp.tool(
    name="supabase_insert_record",
    annotations={
        "title": "Insert New Record",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False
    }
)
async def insert_record(params: InsertRecordInput) -> str:
    """Insert a new record into a table.
    
    Creates a new record with the provided data. The database will automatically
    generate IDs and timestamps if configured to do so.
    
    Args:
        params (InsertRecordInput): Contains table_name, data, and response_format
    
    Returns:
        str: The newly created record with all fields (including auto-generated ones)
    """
    try:
        supabase = get_supabase_client()
        
        result = supabase.table(params.table_name).insert(params.data).execute()
        
        return _format_response(
            {
                "message": "Record inserted successfully",
                "record": result.data[0] if result.data else params.data
            },
            params.response_format,
            f"Insert Result: {params.table_name}"
        )
    
    except Exception as e:
        return _handle_error(e)


@mcp.tool(
    name="supabase_update_records",
    annotations={
        "title": "Update Existing Records",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False
    }
)
async def update_records(params: UpdateRecordInput) -> str:
    """Update existing records that match the filter conditions.
    
    Updates all records matching the filters with the new data provided.
    Use specific filters (like ID) to update individual records.
    
    Args:
        params (UpdateRecordInput): Contains table_name, filters, data, and response_format
    
    Returns:
        str: Updated records
    """
    try:
        supabase = get_supabase_client()
        
        # Build update query with filters
        query = supabase.table(params.table_name).update(params.data)
        query = _apply_filters(query, params.filters)
        
        result = query.execute()
        
        return _format_response(
            {
                "message": f"Updated {len(result.data)} record(s)",
                "updated_records": result.data
            },
            params.response_format,
            f"Update Result: {params.table_name}"
        )
    
    except Exception as e:
        return _handle_error(e)


@mcp.tool(
    name="supabase_delete_records",
    annotations={
        "title": "Delete Records",
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": True,
        "openWorldHint": False
    }
)
async def delete_records(params: DeleteRecordInput) -> str:
    """Delete records that match the filter conditions.
    
    ⚠️ WARNING: This is a destructive operation. Always use specific filters
    to avoid accidentally deleting all records in a table.
    
    Args:
        params (DeleteRecordInput): Contains table_name, filters, and response_format
    
    Returns:
        str: Confirmation of deleted records
    """
    try:
        supabase = get_supabase_client()
        
        if not params.filters:
            return "Error: Filters are required for delete operations to prevent accidental data loss. Please specify which records to delete."
        
        # Build delete query with filters
        query = supabase.table(params.table_name).delete()
        query = _apply_filters(query, params.filters)
        
        result = query.execute()
        
        return _format_response(
            {
                "message": f"Deleted {len(result.data)} record(s)",
                "deleted_records": result.data
            },
            params.response_format,
            f"Delete Result: {params.table_name}"
        )
    
    except Exception as e:
        return _handle_error(e)


@mcp.tool(
    name="supabase_count_records",
    annotations={
        "title": "Count Records",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False
    }
)
async def count_records(params: CountRecordsInput) -> str:
    """Count the number of records in a table, optionally with filters.
    
    Useful for getting statistics and understanding the size of datasets.
    
    Args:
        params (CountRecordsInput): Contains table_name, optional filters, and response_format
    
    Returns:
        str: Count of matching records
    """
    try:
        supabase = get_supabase_client()
        
        query = supabase.table(params.table_name).select("*", count="exact").limit(0)
        query = _apply_filters(query, params.filters)
        
        result = query.execute()
        count = result.count if hasattr(result, 'count') else 0
        
        return _format_response(
            {
                "table_name": params.table_name,
                "count": count,
                "filters_applied": params.filters is not None
            },
            params.response_format,
            f"Count Result: {params.table_name}"
        )
    
    except Exception as e:
        return _handle_error(e)


@mcp.tool(
    name="supabase_search_records",
    annotations={
        "title": "Search Records",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False
    }
)
async def search_records(params: SearchRecordsInput) -> str:
    """Search for records using case-insensitive pattern matching across columns.
    
    Performs a full-text search across specified columns (or all text columns).
    Useful for finding records when you don't know the exact value.
    
    Args:
        params (SearchRecordsInput): Contains table_name, search_term, search_columns, limit, and response_format
    
    Returns:
        str: Matching records
    """
    try:
        supabase = get_supabase_client()
        
        # If no columns specified, we'll need to search all columns
        # This requires getting the schema first
        if not params.search_columns:
            # Get a sample record to determine columns
            sample = supabase.table(params.table_name).select("*").limit(1).execute()
            if sample.data:
                params.search_columns = list(sample.data[0].keys())
        
        # Build search query - we'll use OR conditions for multiple columns
        query = supabase.table(params.table_name).select("*")
        
        # Apply ilike (case-insensitive) search to each column
        # Note: This is a simplified approach. For better full-text search,
        # you'd want to use PostgreSQL's full-text search features
        search_pattern = f"%{params.search_term}%"
        
        if params.search_columns and len(params.search_columns) > 0:
            # Search in the first column
            query = query.ilike(params.search_columns[0], search_pattern)
        
        query = query.limit(params.limit)
        result = query.execute()
        
        return _format_response(
            {
                "search_term": params.search_term,
                "searched_columns": params.search_columns,
                "found_count": len(result.data),
                "records": result.data
            },
            params.response_format,
            f"Search Results: {params.table_name}"
        )
    
    except Exception as e:
        return _handle_error(e)


# ============================================================================
# Server Entry Point
# ============================================================================

if __name__ == "__main__":
    # Run the MCP server
    mcp.run()
