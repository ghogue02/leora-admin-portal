# Wine Distribution Domain Knowledge

This reference provides essential context about the wine distribution industry and business operations to help Claude better understand and work with Wellcrafted CRM data.

## Industry Overview

Wine distribution is a three-tier system in the US:
1. **Producers/Wineries** - Create and bottle wine
2. **Distributors** (like Wellcrafted's clients) - Buy from producers, sell to retailers/restaurants
3. **Retailers/Restaurants** - Sell to end consumers

Wellcrafted serves **wine distributors** who manage relationships with both producers and customers (restaurants/retailers).

## Core Business Entities

### Customers
Restaurants, wine shops, retail stores, and hospitality venues that purchase wine from the distributor.

**Key Attributes:**
- Business name and contact information
- License numbers (required for alcohol sales)
- Delivery addresses (may differ from billing)
- Payment terms (Net 30, Net 60, etc.)
- Credit limits
- Sales territory/region
- Account status (active, inactive, credit hold)
- Preferred delivery days/times

**Customer Types:**
- **On-Premise**: Restaurants, bars, hotels (consumption on-site)
- **Off-Premise**: Wine shops, grocery stores, retail (take-home sales)

### Products (Wines)

**Key Attributes:**
- Producer/Winery name
- Wine name and vintage (year)
- Varietal (grape type: Cabernet Sauvignon, Chardonnay, Pinot Noir, etc.)
- Region/Appellation (Napa Valley, Bordeaux, etc.)
- Bottle size (750ml standard, also magnums, splits, etc.)
- Case configuration (typically 12 bottles per case)
- Pricing (wholesale, suggested retail)
- Alcohol content (ABV)
- Product codes/SKUs

**Wine Classifications:**
- **Still Wine**: Regular non-sparkling wine (most common)
- **Sparkling**: Champagne, Prosecco, Cava
- **Fortified**: Port, Sherry, Madeira
- **Dessert Wine**: Sweet wines like Sauternes

**Quality Tiers:**
- **Value/Entry**: Under $15 retail
- **Premium**: $15-30 retail
- **Super-Premium**: $30-50 retail
- **Ultra-Premium**: $50+ retail

### Orders

Purchase orders from customers to the distributor.

**Order Lifecycle:**
1. **Pending**: Order taken but not yet confirmed
2. **Confirmed**: Order confirmed, awaiting fulfillment
3. **In Progress**: Being picked/packed
4. **Shipped/Delivered**: On the way or delivered
5. **Completed**: Delivered and invoiced
6. **Cancelled**: Order cancelled

**Key Attributes:**
- Customer information
- Order date and requested delivery date
- Order items (products, quantities, pricing)
- Total amount
- Delivery instructions
- Special requests or notes
- Sales representative
- Payment method

**Order Items:**
- Product/SKU
- Quantity (usually in cases, sometimes bottles)
- Unit price (per case or bottle)
- Discounts applied
- Line total

### Inventory

Stock levels and warehouse management.

**Key Concepts:**
- **On Hand**: Physical inventory in warehouse
- **Allocated**: Reserved for specific customers/orders
- **Available**: On hand minus allocated
- **On Order**: Expected from producer
- **Backorder**: Customer orders waiting for stock

**Inventory Challenges:**
- Limited availability wines (allocations from producers)
- Vintage changes (2023 vintage replaced by 2024)
- Seasonal demand variations
- Perishability concerns (though wine is stable, old inventory depreciates)

### Producers/Suppliers

Wineries and wine producers that supply the distributor.

**Key Attributes:**
- Winery name and location
- Portfolio of wines
- Minimum order quantities (MOQ)
- Lead times
- Allocation policies
- Terms and pricing
- Representative/contact

### Sales Territories

Geographic regions assigned to sales representatives.

**Common Structures:**
- By city or county
- By ZIP code ranges
- By customer type (on-premise vs off-premise)
- By channel (restaurants, hotels, retail)

## Common Business Operations

### Order Taking
Sales reps visit customers, take orders, manage relationships.

**Process:**
1. Customer places order (phone, email, online, or in-person)
2. Check product availability
3. Verify customer credit and payment terms
4. Confirm pricing and apply any discounts
5. Enter order into system
6. Set delivery date
7. Send order confirmation

### Delivery Management
Logistics and fulfillment operations.

**Process:**
1. Pick products from warehouse
2. Stage orders by delivery route
3. Load delivery trucks
4. Deliver to customers
5. Obtain signature/proof of delivery
6. Process invoice

**Considerations:**
- Route optimization for efficiency
- Temperature control for wine transport
- Delivery windows (restaurants prefer morning)
- Driver license requirements (alcohol delivery)

### Sales Analytics

Key metrics distributors track:

**Revenue Metrics:**
- Total sales volume (cases and dollars)
- Sales by territory/region
- Sales by customer type
- Sales by product category
- Sales by sales rep

**Operational Metrics:**
- Order fill rate (% of orders fulfilled completely)
- Inventory turnover
- Days sales outstanding (DSO)
- Gross margin by product/category

**Customer Metrics:**
- Customer acquisition and retention
- Average order value
- Order frequency
- Customer lifetime value
- Top customers by revenue

### Pricing and Discounts

**Pricing Structure:**
- List price (standard wholesale price)
- Contract pricing (negotiated rates)
- Volume discounts (buy more, save more)
- Promotional pricing (temporary specials)
- Program allowances (marketing support)

**Common Discount Types:**
- Case discount (quantity tiers)
- Mix-and-match (bulk discounts across products)
- Promotional deals (limited time offers)
- Payment discounts (early payment incentives)
- Placement fees (new product introductions)

## Wine-Specific Terminology

### Basics
- **Varietal**: Type of grape (Cabernet Sauvignon, Chardonnay, etc.)
- **Vintage**: Year the grapes were harvested
- **Appellation**: Geographic region where grapes are grown
- **Estate**: Wine made from grapes grown on winery's own land
- **Reserve**: Term indicating special or premium wine (not regulated in US)

### Production Terms
- **Fermentation**: Process converting grape sugar to alcohol
- **Oak Aging**: Aging wine in oak barrels for flavor
- **Malolactic**: Secondary fermentation softening acidity
- **Blend**: Wine made from multiple grape varieties

### Size/Format
- **Split**: 375ml (half bottle)
- **Standard**: 750ml (typical bottle)
- **Magnum**: 1.5L (two bottles)
- **Jeroboam**: 3L (four bottles)

### Tasting Notes
- **Body**: Light, medium, or full
- **Tannin**: Astringent compounds from grape skins
- **Acidity**: Fresh, crisp quality
- **Finish**: Aftertaste length

## Regulatory Considerations

**Alcohol Beverage Control (ABC):**
- Licenses required for all parties
- Age verification for delivery
- State-specific regulations vary significantly
- Some states control distribution (control states)

**Compliance Requirements:**
- Accurate record keeping
- Tax reporting
- License renewals
- Delivery restrictions (dry counties, Sunday sales, etc.)

## Seasonality and Trends

**Seasonal Patterns:**
- Q4 (Oct-Dec): Highest sales - holidays
- Summer: Rosé and white wine peak
- Fall: Red wine season begins
- January: Slowest month (post-holiday)

**Industry Trends:**
- Direct-to-consumer (DTC) growth
- Natural and organic wines increasing
- Canned wine and alternative formats
- E-commerce adoption
- Sustainability focus

## Common Queries and Use Cases

When working with Wellcrafted data, users commonly need:

### Customer-Related
- "Who are our top customers this quarter?"
- "Show me all restaurants in the downtown area"
- "Which accounts have outstanding balances?"
- "Find contact info for XYZ Wine Bar"
- "List customers who haven't ordered in 60 days"

### Product/Inventory
- "Do we have any Opus One in stock?"
- "Show me all Pinot Noirs under $30"
- "What's our best-selling Chardonnay?"
- "Which items are running low on inventory?"
- "List new arrivals this month"

### Orders/Sales
- "Create an order for ABC Restaurant"
- "Show me all pending deliveries for tomorrow"
- "What were last month's sales by region?"
- "Track order #12345"
- "Show me unfulfilled backorders"

### Analytics
- "Compare Q3 sales to last year"
- "Which sales rep had the highest revenue?"
- "What's our average order value?"
- "Show me sales trends for the past 6 months"
- "Calculate inventory turnover by category"

## Tips for Working with Wine Distribution Data

1. **Quantities**: Remember wine is typically sold in cases (12 bottles), not individual bottles
2. **Pricing**: Wholesale pricing is typically 50-60% of retail price
3. **Vintage Transitions**: When a new vintage arrives, the old vintage goes on closeout
4. **Allocations**: Limited availability wines have maximum quantities per customer
5. **Minimum Orders**: Many products have minimum order requirements (cases or dollars)
6. **Regional Variations**: Sales patterns vary significantly by geography
7. **Customer Segmentation**: On-premise vs off-premise have different buying patterns
8. **Margin Management**: Product margins vary widely (commodity wines vs. allocated wines)

## References

For more information:
- Wine Institute (industry association)
- National Association of Wine Retailers
- Wine & Spirits Wholesalers of America (WSWA)
- Wine Business Monthly (trade publication)
