---
name: wellcrafted-supabase
description: Comprehensive MCP server integration for the Wellcrafted wine distributor CRM platform hosted on Supabase. Use this skill when users ask to query, update, analyze, or manage data in the Wellcrafted system, including customers, orders, products, inventory, sales, or any wine distribution business operations. Automatically triggers for requests involving the Wellcrafted database, wine distributor CRM, customer management, order tracking, inventory management, sales analytics, or any natural language queries about business data.
---

# Wellcrafted Supabase MCP Integration

## Overview

This skill provides seamless integration with the Wellcrafted wine distributor CRM system through a Model Context Protocol (MCP) server. The MCP server connects directly to your Supabase database, enabling Claude to query, analyze, and manage all aspects of your wine distribution business using natural language.

**Key Capabilities:**
- Query customer, order, product, and inventory data
- Insert new records (orders, customers, products, etc.)
- Update existing records with new information
- Generate business analytics and reports
- Search across all tables for specific information
- Manage relationships between entities (customers, orders, products)

## When to Use This Skill

This skill automatically activates for any requests related to:
- **Customer Management**: Finding customer information, updating contact details, viewing purchase history
- **Order Management**: Creating new orders, tracking order status, analyzing order trends
- **Product/Inventory**: Checking stock levels, managing wine catalog, pricing information
- **Sales Analytics**: Revenue reports, sales trends, territory performance
- **Data Exploration**: Discovering what tables exist, understanding data structure
- **Business Operations**: Any natural language query about the wine distribution business

## MCP Server Setup

The Wellcrafted MCP server is a Python-based service that connects to your Supabase database.

### Installation

The MCP server is located at `scripts/supabase_mcp.py` and requires:
- Python 3.8+
- Dependencies: `mcp`, `supabase`, `httpx`, `pydantic`

To install dependencies:
```bash
pip install mcp supabase httpx pydantic
```

### Configuration

The MCP server requires environment variables for Supabase authentication. These should be configured in your Claude Desktop config or MCP client:

```json
{
  "mcpServers": {
    "wellcrafted": {
      "command": "python",
      "args": ["/path/to/scripts/supabase_mcp.py"],
      "env": {
        "SUPABASE_URL": "https://zqezunzlyjkseugujkrl.supabase.co",
        "SUPABASE_SERVICE_ROLE_KEY": "your_service_role_key_here"
      }
    }
  }
}
```

**Security Note**: Use `SUPABASE_SERVICE_ROLE_KEY` for full database access (required for writes), or `SUPABASE_ANON_KEY` for read-only operations.

## Core Workflow

### 1. Start by Discovering the Schema

When working with the Wellcrafted database for the first time, always begin by understanding what tables and data are available:

**Step 1: List Available Tables**
```
Use the supabase_list_tables tool to discover all tables in the database
```

**Step 2: Describe Table Structure**
```
For each relevant table, use supabase_describe_table to understand:
- Column names and types
- Sample data
- Row counts
```

This exploration phase helps you understand the business domain and data structure before answering user queries.

### 2. Querying Data

Use `supabase_query_table` for most data retrieval operations. This is the most flexible and commonly used tool.

**Basic Query Examples:**

```python
# Find all active customers
{
  "table_name": "customers",
  "filters": {"status": "active"},
  "limit": 50
}

# Get recent orders, sorted by date
{
  "table_name": "orders",
  "order_by": "-created_at",
  "limit": 20
}

# Find orders for a specific customer
{
  "table_name": "orders",
  "filters": {"customer_id": 123},
  "columns": ["id", "order_date", "total_amount", "status"]
}
```

**Advanced Filtering:**

```python
# Orders over $1000 in the last month
{
  "table_name": "orders",
  "filters": {
    "total_amount": {"operator": "gte", "value": 1000},
    "created_at": {"operator": "gte", "value": "2024-09-01"}
  },
  "order_by": "-total_amount"
}
```

### 3. Inserting New Records

Use `supabase_insert_record` to create new entries in the database:

```python
# Add a new customer
{
  "table_name": "customers",
  "data": {
    "name": "Acme Wine Shop",
    "email": "contact@acmewine.com",
    "phone": "(555) 123-4567",
    "address": "123 Main St, San Francisco, CA",
    "status": "active"
  }
}

# Create a new order
{
  "table_name": "orders",
  "data": {
    "customer_id": 123,
    "order_date": "2024-10-18",
    "status": "pending",
    "total_amount": 2500.00,
    "notes": "Delivery requested for Friday"
  }
}
```

### 4. Updating Records

Use `supabase_update_records` to modify existing data:

```python
# Update customer contact information
{
  "table_name": "customers",
  "filters": {"id": 123},
  "data": {
    "email": "newemail@acmewine.com",
    "phone": "(555) 987-6543"
  }
}

# Mark order as completed
{
  "table_name": "orders",
  "filters": {"id": 456},
  "data": {
    "status": "completed",
    "completed_at": "2024-10-18T15:30:00Z"
  }
}
```

### 5. Searching and Analytics

**Full-Text Search:**
```python
# Find customers or products by name
{
  "table_name": "products",
  "search_term": "Chardonnay",
  "search_columns": ["name", "description", "producer"],
  "limit": 20
}
```

**Counting and Aggregation:**
```python
# Count active customers by region
{
  "table_name": "customers",
  "filters": {"status": "active", "region": "west"}
}
```

## Common Use Cases

### Customer Lookup

**User Request**: "Show me all the details for customer XYZ Wine Shop"

**Workflow**:
1. Search customers table for matching name: `supabase_search_records`
2. Once found, get full details: `supabase_query_table` with ID filter
3. Optionally, get their order history from orders table
4. Present complete customer profile

### Sales Analytics

**User Request**: "What were our top selling wines last month?"

**Workflow**:
1. Query orders table with date filters for last month
2. Join with products/wines table if needed (or query separately)
3. Aggregate by product
4. Sort by quantity or revenue
5. Present formatted results

### Inventory Check

**User Request**: "Do we have any Pinot Noir in stock?"

**Workflow**:
1. Search products table: `supabase_search_records` with "Pinot Noir"
2. For matching products, check inventory levels
3. Present stock status with product details

### Order Management

**User Request**: "Create a new order for customer ABC Wine Bar - 3 cases of Cabernet, delivery Friday"

**Workflow**:
1. Find customer ID: `supabase_query_table` on customers
2. Find product ID: `supabase_search_records` on products
3. Create order: `supabase_insert_record` on orders table
4. Optionally, create order_items entries
5. Confirm order created with details

## Business Context: Wine Distribution

Wellcrafted is a comprehensive CRM platform for wine distributors. Understanding the wine distribution business model helps provide better assistance:

**Key Entities:**
- **Customers**: Restaurants, wine shops, retailers who purchase wine
- **Products/Wines**: The wine catalog with producers, vintages, pricing
- **Orders**: Purchase orders from customers, including order items
- **Inventory**: Stock levels and warehouse management
- **Producers/Suppliers**: Wineries and wine producers
- **Sales Territory**: Geographic regions for sales management

**Common Business Operations:**
- Taking orders from restaurant/retail customers
- Managing wine inventory and allocation
- Tracking delivery schedules and logistics
- Sales reporting and territory performance
- Customer relationship management
- Pricing and discount management

**Wine Industry Terminology:**
- **Cases**: Wine is typically sold in 12-bottle cases
- **SKU**: Product identifier for specific wines
- **Allocation**: Limited availability wines assigned to customers
- **Vintage**: Year the grapes were harvested
- **Producer**: Winery or wine maker
- **Varietal**: Type of grape (Cabernet, Chardonnay, etc.)
- **Appellation**: Geographic wine region

## Best Practices

### Data Exploration
- Always start with `supabase_list_tables` when unfamiliar with the schema
- Use `supabase_describe_table` to understand data structure before complex queries
- Check row counts to understand data volumes

### Query Optimization
- Use `columns` parameter to retrieve only needed fields
- Apply filters to reduce result sets
- Use pagination (`limit` and `offset`) for large datasets
- Prefer specific queries over broad searches

### Data Integrity
- Always use filters when updating or deleting records
- Verify record existence before updating
- Use transactions for related operations (if available)
- Validate data before inserting new records

### Response Formatting
- Use `response_format: "markdown"` for user-facing results
- Use `response_format: "json"` for programmatic processing or complex data
- Summarize large result sets for readability

### Error Handling
- Check for Row Level Security (RLS) policy restrictions
- Handle missing tables or columns gracefully
- Provide helpful suggestions when queries fail
- Verify authentication credentials if access is denied

## Reference Documentation

For detailed information about the wine distribution domain and database schema, see:
- [references/wine_distribution_domain.md](references/wine_distribution_domain.md) - Wine industry terminology and business processes

## Troubleshooting

**"Table not found" errors:**
- Run `supabase_list_tables` to see available tables
- Check for typos in table names (case-sensitive)
- Verify database connection with credentials

**"Permission denied" errors:**
- Check if Row Level Security (RLS) policies are enabled
- Verify you're using SERVICE_ROLE_KEY for write operations
- Confirm table access permissions in Supabase dashboard

**Empty results:**
- Verify table actually contains data with `supabase_count_records`
- Check if filters are too restrictive
- Try broader search terms

**Response truncation:**
- Results are limited to 25,000 characters
- Use pagination to retrieve data in chunks
- Use more specific filters to reduce result size
